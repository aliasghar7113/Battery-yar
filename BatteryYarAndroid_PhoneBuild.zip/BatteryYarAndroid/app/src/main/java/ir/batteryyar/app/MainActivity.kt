package ir.batteryyar.app

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.platform.LocalContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Sale(val id: Long, val customer: String, val phone: String, val amp: String,
                val brand: String, val serial: String, val warranty: String,
                val buy: Long, val sell: Long, val date: String)

class BatteryDb(context: android.content.Context) :
    SQLiteOpenHelper(context, "battery_yar.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE sales(
            id INTEGER PRIMARY KEY AUTOINCREMENT, customer TEXT, phone TEXT, amp TEXT,
            brand TEXT, serial TEXT UNIQUE, warranty TEXT, buy INTEGER, sell INTEGER, date TEXT)""")
        db.execSQL("""CREATE TABLE expenses(
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, amount INTEGER, date TEXT)""")
        db.execSQL("""CREATE TABLE stock(
            amp TEXT PRIMARY KEY, quantity INTEGER NOT NULL DEFAULT 0)""")
        listOf("50","55","60","66","74").forEach {
            val v = ContentValues().apply { put("amp", it); put("quantity", 0) }
            db.insert("stock", null, v)
        }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun addSale(customer:String, phone:String, amp:String, brand:String, serial:String,
                 warranty:String, buy:Long, sell:Long): Boolean {
        return try {
            val v = ContentValues().apply {
                put("customer", customer); put("phone", phone); put("amp", amp)
                put("brand", brand); put("serial", serial); put("warranty", warranty)
                put("buy", buy); put("sell", sell)
                put("date", SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date()))
            }
            writableDatabase.insertOrThrow("sales", null, v)
            true
        } catch (_: Exception) { false }
    }
    fun sales(): List<Sale> {
        val out = mutableListOf<Sale>()
        readableDatabase.rawQuery("SELECT * FROM sales ORDER BY id DESC", null).use { c ->
            while(c.moveToNext()) out.add(Sale(c.getLong(0),c.getString(1),c.getString(2),
                c.getString(3),c.getString(4),c.getString(5),c.getString(6),
                c.getLong(7),c.getLong(8),c.getString(9)))
        }
        return out
    }
    fun stock(): Map<String,Int> {
        val out = linkedMapOf<String,Int>()
        readableDatabase.rawQuery("SELECT amp,quantity FROM stock ORDER BY CAST(amp AS INTEGER)", null).use { c ->
            while(c.moveToNext()) out[c.getString(0)] = c.getInt(1)
        }
        return out
    }
    fun changeStock(amp:String, delta:Int) {
        writableDatabase.execSQL("UPDATE stock SET quantity=MAX(0, quantity + ?) WHERE amp=?", arrayOf(delta,amp))
    }
    fun addExpense(title:String, amount:Long) {
        val v = ContentValues().apply {
            put("title",title); put("amount",amount)
            put("date",SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date()))
        }
        writableDatabase.insert("expenses",null,v)
    }
    fun expensesTotal():Long {
        readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM expenses",null).use {
            return if(it.moveToFirst()) it.getLong(0) else 0L
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = BatteryDb(this)
        setContent { BatteryYarApp(db) }
    }
}

@Composable
fun BatteryYarApp(db: BatteryDb) {
    var page by remember { mutableStateOf("خانه") }
    var refresh by remember { mutableIntStateOf(0) }
    MaterialTheme {
        Scaffold(
            topBar = { TopAppBarCompat("باطری‌یار | حسابداری مغازه") },
            bottomBar = {
                NavigationBar {
                    listOf("خانه","فروش","انبار","گزارش","هزینه").forEach { item ->
                        NavigationBarItem(selected=page==item,onClick={page=item},
                            icon={}, label={Text(item)})
                    }
                }
            }
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement=Arrangement.spacedBy(12.dp)) {
                when(page) {
                    "خانه" -> HomePage(db, refresh)
                    "فروش" -> SalePage(db) { refresh++ }
                    "انبار" -> StockPage(db, refresh) { amp,delta -> db.changeStock(amp,delta); refresh++ }
                    "گزارش" -> ReportPage(db, refresh)
                    "هزینه" -> ExpensePage(db) { refresh++ }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun TopAppBarCompat(title:String) {
    CenterAlignedTopAppBar(title={Text(title, textAlign=TextAlign.Center)})
}

@Composable fun HomePage(db:BatteryDb, refresh:Int) {
    val sales = remember(refresh) { db.sales() }
    val profit = sales.sumOf { it.sell-it.buy }
    Text("خوش آمدی 👋", style=MaterialTheme.typography.headlineSmall)
    Card { Column(Modifier.fillMaxWidth().padding(16.dp)) {
        Text("فروش‌های ثبت‌شده: ${sales.size}")
        Text("سود ناخالص ثبت‌شده: ${profit.money()} تومان")
        Text("هزینه‌های ثبت‌شده: ${db.expensesTotal().money()} تومان")
    } }
    Text("امکانات", style=MaterialTheme.typography.titleLarge)
    listOf("ثبت فروش و گارانتی","مدیریت موجودی ۵۰، ۵۵، ۶۰، ۶۶ و ۷۴ آمپر",
        "گزارش سود فروش‌ها","ثبت هزینه‌های روزانه").forEach { Text("• $it") }
    Text("اطلاعات در پایگاه داده داخلی گوشی ذخیره می‌شود.", style=MaterialTheme.typography.bodySmall)
}

@Composable fun SalePage(db:BatteryDb, onSaved:()->Unit) {
    var customer by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var amp by remember { mutableStateOf("60") }
    var brand by remember { mutableStateOf("سپاهان") }
    var serial by remember { mutableStateOf("") }
    var warranty by remember { mutableStateOf("24 ماه") }
    var buy by remember { mutableStateOf("") }
    var sell by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    Text("ثبت فروش باطری", style=MaterialTheme.typography.headlineSmall)
    OutlinedTextField(customer,{customer=it},label={Text("نام مشتری")},modifier=Modifier.fillMaxWidth())
    OutlinedTextField(phone,{phone=it},label={Text("شماره موبایل")},modifier=Modifier.fillMaxWidth())
    Text("آمپر")
    Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
        listOf("50","55","60","66","74").forEach { a ->
            FilterChip(selected=amp==a,onClick={amp=a},label={Text(a)})
        }
    }
    OutlinedTextField(brand,{brand=it},label={Text("برند باطری")},modifier=Modifier.fillMaxWidth())
    OutlinedTextField(serial,{serial=it},label={Text("شماره سریال (یکتا)")},modifier=Modifier.fillMaxWidth())
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=!expanded}) {
        OutlinedTextField(value=warranty, onValueChange={}, label={Text("مدت گارانتی")}, modifier=Modifier.menuAnchor().fillMaxWidth(), readOnly=true)
        ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) {
            listOf("12 ماه","18 ماه","24 ماه","30 ماه","36 ماه").forEach {
                DropdownMenuItem(text={Text(it)},onClick={warranty=it;expanded=false})
            }
        }
    }
    OutlinedTextField(buy,{buy=it},label={Text("قیمت خرید (تومان)")},modifier=Modifier.fillMaxWidth())
    OutlinedTextField(sell,{sell=it},label={Text("قیمت فروش (تومان)")},modifier=Modifier.fillMaxWidth())
    Button(onClick={
        val b=buy.toLongOrNull(); val s=sell.toLongOrNull()
        msg = when {
            customer.isBlank() || serial.isBlank() -> "نام مشتری و شماره سریال را وارد کن."
            b==null || s==null || b<0 || s<=0 -> "قیمت خرید و فروش را درست وارد کن."
            else -> if(db.addSale(customer,phone,amp,brand,serial,warranty,b,s)) {
                onSaved(); customer="";phone="";serial="";buy="";sell="";"فروش و گارانتی ثبت شد."
            } else "این شماره سریال قبلاً ثبت شده یا خطایی رخ داده است."
        }
    },modifier=Modifier.fillMaxWidth()) { Text("ثبت فروش") }
    if(msg.isNotBlank()) Text(msg,color=MaterialTheme.colorScheme.primary)
}

@Composable fun StockPage(db:BatteryDb, refresh:Int, change:(String,Int)->Unit) {
    Text("موجودی انبار", style=MaterialTheme.typography.headlineSmall)
    db.stock().forEach { (amp,qty) ->
        Card { Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement=Arrangement.SpaceBetween) {
            Column { Text("باطری $amp آمپر"); Text("موجودی: $qty عدد") }
            Row {
                TextButton(onClick={change(amp,-1)}) { Text("−") }
                TextButton(onClick={change(amp,1)}) { Text("+") }
            }
        } }
    }
    Text("نکته: ورود و خروج انبار در این نسخه به‌صورت دستی ثبت می‌شود.")
}

@Composable fun ReportPage(db:BatteryDb, refresh:Int) {
    val sales=remember(refresh){db.sales()}
    val total=sales.sumOf{it.sell}
    val cost=sales.sumOf{it.buy}
    Text("گزارش فروش", style=MaterialTheme.typography.headlineSmall)
    Card { Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Text("تعداد فاکتورها: ${sales.size}")
        Text("مجموع فروش: ${total.money()} تومان")
        Text("بهای خرید: ${cost.money()} تومان")
        Text("سود ناخالص: ${(total-cost).money()} تومان")
        Text("هزینه‌ها: ${db.expensesTotal().money()} تومان")
        Text("سود پس از هزینه‌ها: ${(total-cost-db.expensesTotal()).money()} تومان")
    } }
    Text("آخرین فروش‌ها", style=MaterialTheme.typography.titleMedium)
    sales.take(30).forEach { Text("${it.date} | ${it.customer} | ${it.amp} آمپر | ${it.sell.money()} تومان") }
}

@Composable fun ExpensePage(db:BatteryDb, onSaved:()->Unit) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    Text("ثبت هزینه روزانه", style=MaterialTheme.typography.headlineSmall)
    OutlinedTextField(title,{title=it},label={Text("شرح هزینه")},modifier=Modifier.fillMaxWidth())
    OutlinedTextField(amount,{amount=it},label={Text("مبلغ (تومان)")},modifier=Modifier.fillMaxWidth())
    Button(onClick={
        val a=amount.toLongOrNull()
        if(title.isBlank() || a==null || a<=0) msg="شرح و مبلغ معتبر وارد کن."
        else { db.addExpense(title,a); title="";amount="";msg="هزینه ثبت شد.";onSaved() }
    },modifier=Modifier.fillMaxWidth()) { Text("ثبت هزینه") }
    if(msg.isNotBlank()) Text(msg)
}

fun Long.money():String = String.format(Locale.US,"%,d",this)
